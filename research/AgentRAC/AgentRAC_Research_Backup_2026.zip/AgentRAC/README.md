# ClimateNetAI-AgentRAC: enhanced offline research prototype

This is a separate reproducible research experiment. **It does not alter the deployed ClimateNetAI app or control any network.**

## Run

Install `pandas`, `numpy`, `scikit-learn` and run `python run_enhanced.py`. `python run_experiment.py` reproduces the previous prototype.

## Added functionality

`agent_controller.py` defines auditable tools/policy checks for training-range context, telemetry provenance, observation staleness, and the existing prospective RBE state. It returns evidence, reason codes, human-review requirements and recommended next steps. All actions are recommendations; `execution_authorized=False` by construction.

`run_enhanced.py` compares identical chronological holdout records under baseline, RBE, and AgentRAC, then separately runs synthetic rule perturbations. Stress tests are **not** additional real-world measurements.

## Research integrity

The existing AgentRAC and RBE policies may have identical accepted-prediction errors. The enhanced controller's novel value is *auditable workflow behavior* and safety checks, not demonstrated superior RSSI forecasting. RBE uses prior holdout outcomes only; the first five holdout records are warm-up. The 252 records are treated as supplied representative observations, not raw daily timestamps. No model deployment or real-world safety outcome is claimed.
